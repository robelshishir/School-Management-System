/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package school.management;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.table.DefaultTableModel;
/**
 *
 * @author User
 */
public class management extends javax.swing.JFrame {

    /**
     * Creates new form management
     */
    Connection conn = null;
    public void connect() {
        
        try {
            // db parameters
            String url = "jdbc:sqlite:school.sqlite";
            // create a connection to the database
            conn = DriverManager.getConnection(url);
            createTable();
            System.out.println("Connection to SQLite has been established.");
            
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        } finally {
            /*
            try {
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException ex) {
                System.out.println(ex.getMessage());
            }
            */
        }
    }
    Statement statement;
    public void createTable(){
       
        try {
            statement = conn.createStatement();
            statement.setQueryTimeout(30); 
            statement.executeUpdate("create table if not exists Student(name varchar,age int,gender varchar,studentId varchar,password varchar)");
            statement.executeUpdate("create table if not exists Course(name varchar,code varchar)");
            statement.execute("create table if not exists Registration(StudentId int,CourseId int,Semester int,FOREIGN KEY(StudentId) REFERENCES Student(rowid),FOREIGN KEY(CourseId) REFERENCES Course(rowid))");
            
        } catch (SQLException ex) {
            Logger.getLogger(management.class.getName()).log(Level.SEVERE, null, ex);
        }
         
    }
    
    public management() {
        initComponents();
        connect();
        updateCourseTable();
        updateStudentTable();
        updateRegTable();
    }
    Object students[][]=new Object[1000][6];
    Object courses[][]=new Object[1000][3];
    Object regs[][]=new Object[1000][3];
    int studentCount=0;
    int courseCount=0;
    int regCount=0;
    public void updateCourseTable(){
        //DefaultTableModel model = //(DefaultTableModel) courseTable.getModel();
        courses=new Object[1000][3];
        courseTable.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
      
        try {
            
            ResultSet rs = statement.executeQuery("select rowid,* from course");
            courseCount=0;
            while(rs.next())
            {
                // read the result set
                courses[courseCount][0]=rs.getInt("rowid");
                courses[courseCount][1]=rs.getString("name");
                courses[courseCount][2]=rs.getString("code");
                courseCount++;
                //System.out.println("name = " + rs.getString("name"));
                //System.out.println("id = " + rs.getInt("id"));        
            } 
            
            courseTable.setModel(new javax.swing.table.DefaultTableModel(
                courses,
                new String [] {
                    "id","name", "code"
                }
            ));            
            
        } catch (Exception ex) {
            Logger.getLogger(management.class.getName()).log(Level.SEVERE, null, ex);
        }
        setupRegEdit();
    }
    
    
    public void updateStudentTable(){
        students=new Object[1000][6];
        //DefaultTableModel model = //(DefaultTableModel) courseTable.getModel();
        studentTable.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
      
        try {
            
            ResultSet rs = statement.executeQuery("select rowid,* from student");
            studentCount=0;
            while(rs.next())
            {
                // read the result set
                students[studentCount][0]=rs.getInt("rowid");
                students[studentCount][1]=rs.getString("name");
                students[studentCount][2]=rs.getInt("age");
                students[studentCount][3]=rs.getString("gender");
                students[studentCount][4]=rs.getString("studentId");
                students[studentCount][5]=rs.getString("password");
                studentCount++;
                //System.out.println("name = " + rs.getString("name"));
                //System.out.println("id = " + rs.getInt("id"));        
            } 
            
            studentTable.setModel(new javax.swing.table.DefaultTableModel(
                students,
                new String [] {
                    "id","name", "age","gender","studentId","password"
                }
            ));            
            
        } catch (Exception ex) {
            Logger.getLogger(management.class.getName()).log(Level.SEVERE, null, ex);
        }
        setupRegEdit();

    }
    
    
    public void updateRegTable(){
        regs=new Object[1000][3];
        regTable.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        try {
            int studentId=Integer.parseInt(""+students[reg_student.getSelectedIndex()][0]);
            int semesterId=reg_semester.getSelectedIndex()+1;
            ResultSet rs = statement.executeQuery("select Registration.rowid,code,Semester from Registration left join Course on Course.rowid=Registration.CourseId where StudentId="+studentId+" and Semester="+semesterId);
            regCount=0;
            while(rs.next())
            {
                // read the result set
                regs[regCount][0]=rs.getInt("rowid");
                regs[regCount][1]=rs.getString("code");
                regs[regCount][2]=rs.getInt("Semester");
                regCount++;
                //System.out.println("name = " + rs.getString("name"));
                //System.out.println("id = " + rs.getInt("id"));        
            } 
            
            regTable.setModel(new javax.swing.table.DefaultTableModel(
                regs,
                new String [] {
                    "id","code", "semester"
                }
            ));            
            
        } catch (Exception ex) {
            Logger.getLogger(management.class.getName()).log(Level.SEVERE, null, ex);
        }    
    }


    public void setupRegEdit(){
        String StudentCombo[]=new String[studentCount];
        for(int i=0;i<studentCount;i++)
        {
            StudentCombo[i]=students[i][1]+"_"+students[i][4];
        }
        String courseCombo[]=new String[courseCount];
        for(int i=0;i<courseCount;i++)
        {
            courseCombo[i]=courses[i][2]+":"+courses[i][1];
        }        
        reg_student.setModel(new javax.swing.DefaultComboBoxModel<>(StudentCombo));
        reg_course.setModel(new javax.swing.DefaultComboBoxModel<>(courseCombo));
    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jTabbedPane1 = new javax.swing.JTabbedPane();
        jPanel1 = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        courseTable = new javax.swing.JTable();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jButton2 = new javax.swing.JButton();
        course_name = new javax.swing.JTextField();
        course_code = new javax.swing.JTextField();
        course_delete = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        jScrollPane3 = new javax.swing.JScrollPane();
        studentTable = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        student_name = new javax.swing.JTextField();
        student_age = new javax.swing.JTextField();
        student_id = new javax.swing.JTextField();
        student_password = new javax.swing.JTextField();
        student_gender = new javax.swing.JComboBox<>();
        student_delete = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        regTable = new javax.swing.JTable();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jButton3 = new javax.swing.JButton();
        reg_student = new javax.swing.JComboBox<>();
        reg_semester = new javax.swing.JComboBox<>();
        jLabel10 = new javax.swing.JLabel();
        reg_course = new javax.swing.JComboBox<>();
        reg_delete = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        courseTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null,null,null}
            },
            new String [] {
                "rowid", "name", "code"
            }
        ));
        jScrollPane2.setViewportView(courseTable);

        jLabel6.setText("Course Name:");

        jLabel7.setText("Course Code:");

        jButton2.setText("Add Course");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        course_delete.setText("Delete");
        course_delete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                course_deleteActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 497, Short.MAX_VALUE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel6)
                            .addComponent(jLabel7))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(course_name)
                            .addComponent(course_code)))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jButton2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 234, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(course_delete, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(course_name, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(course_code, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(6, 6, 6)
                .addComponent(jButton2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 343, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(course_delete)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Course", jPanel1);

        studentTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane3.setViewportView(studentTable);

        jLabel1.setText("Name:");

        jLabel2.setText("Age:");

        jLabel3.setText("Gender:");

        jLabel4.setText("Student Id:");

        jLabel5.setText("Password:");

        jButton1.setText("Add Student");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        student_gender.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Male", "Female" }));

        student_delete.setText("Delete");
        student_delete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                student_deleteActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane3, javax.swing.GroupLayout.DEFAULT_SIZE, 497, Short.MAX_VALUE)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel1)
                            .addComponent(jLabel2)
                            .addComponent(jLabel3)
                            .addComponent(jLabel4)
                            .addComponent(jLabel5))
                        .addGap(11, 11, 11)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(student_name)
                            .addComponent(student_age)
                            .addComponent(student_id)
                            .addComponent(student_password)
                            .addComponent(student_gender, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jButton1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 155, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(student_delete, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 122, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(student_name, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(student_age, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(student_gender, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(student_id, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(student_password, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(9, 9, 9)
                .addComponent(jButton1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 258, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 7, Short.MAX_VALUE)
                .addComponent(student_delete)
                .addContainerGap())
        );

        jTabbedPane1.addTab("Student", jPanel2);

        regTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(regTable);

        jLabel8.setText("Student:");

        jLabel9.setText("Semester:");

        jButton3.setText("Register");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        reg_student.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        reg_student.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                reg_studentItemStateChanged(evt);
            }
        });

        reg_semester.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "1st", "2nd", "3rd", "4th","5th","6th","7th","8th" }));
        reg_semester.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                reg_semesterItemStateChanged(evt);
            }
        });

        jLabel10.setText("Course:");

        reg_course.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        reg_delete.setText("Delete");
        reg_delete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                reg_deleteActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 497, Short.MAX_VALUE)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel8)
                            .addComponent(jLabel9)
                            .addComponent(jLabel10))
                        .addGap(30, 30, 30)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(reg_student, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(reg_semester, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(reg_course, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jButton3, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 138, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(reg_delete, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 133, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap())
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel8)
                            .addComponent(reg_student, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addComponent(jLabel9))
                    .addComponent(reg_semester, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel10)
                    .addComponent(reg_course, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 16, Short.MAX_VALUE)
                .addComponent(jButton3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 309, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(reg_delete)
                .addGap(8, 8, 8))
        );

        jTabbedPane1.addTab("Registration", jPanel3);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jTabbedPane1)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jTabbedPane1)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
            // TODO add your handling code here:
        String name=course_name.getText();
        String code=course_code.getText();
        try {
            statement.executeUpdate("insert into course (name,code) values ('"+name+"','"+code+"')");
            course_name.setText("");
            course_code.setText("");
        } catch (SQLException ex) {
            Logger.getLogger(management.class.getName()).log(Level.SEVERE, null, ex);
        }
        updateCourseTable();
    }//GEN-LAST:event_jButton2ActionPerformed
    String genderArr[]=new String[]{"Male","Female"};
    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        String name=student_name.getText();
        String age=student_age.getText();
        String gender=genderArr[student_gender.getSelectedIndex()];
        String id=student_id.getText();
        String password=student_password.getText();
        try {
            statement.executeUpdate("insert into student (name,age,gender,studentId,password) values ('"+name+"',"+age+",'"+gender+"','"+id+"','"+password+"')");

            student_name.setText("");
            student_age.setText("");
            student_id.setText("");
            student_password.setText("");            
        } catch (SQLException ex) {
            Logger.getLogger(management.class.getName()).log(Level.SEVERE, null, ex);
        }
        updateStudentTable();        
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        // TODO add your handling code here:
        int studentId=Integer.parseInt(""+students[reg_student.getSelectedIndex()][0]);
        int semesterId=reg_semester.getSelectedIndex()+1;
        int courseId=Integer.parseInt(""+courses[reg_course.getSelectedIndex()][0]);
         try {
            statement.executeUpdate("insert into Registration (StudentId,CourseId,Semester) values ("+studentId+","+courseId+","+semesterId+")");
         
        } catch (SQLException ex) {
            Logger.getLogger(management.class.getName()).log(Level.SEVERE, null, ex);
        }    
         updateRegTable();
    }//GEN-LAST:event_jButton3ActionPerformed

    private void reg_studentItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_reg_studentItemStateChanged
        // TODO add your handling code here:
        updateRegTable();
    }//GEN-LAST:event_reg_studentItemStateChanged

    private void reg_semesterItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_reg_semesterItemStateChanged
        // TODO add your handling code here:
        updateRegTable();
    }//GEN-LAST:event_reg_semesterItemStateChanged

    private void reg_deleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_reg_deleteActionPerformed
        // TODO add your handling code here:
        int row=regTable.getSelectedRow();
         if ( row!= -1&&row<regCount) {
            try {
                // remove selected row from the model
                
                statement.execute("delete from Registration where rowid="+regs[row][0]);
            } catch (SQLException ex) {
                Logger.getLogger(management.class.getName()).log(Level.SEVERE, null, ex);
            }
            updateRegTable();
        }       
    }//GEN-LAST:event_reg_deleteActionPerformed

    private void student_deleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_student_deleteActionPerformed
        // TODO add your handling code here:
        int row=studentTable.getSelectedRow();
         if ( row!= -1&&row<studentCount) {
            try {
                // remove selected row from the model
                statement.execute("delete from Registration where StudentId="+students[row][0]);
                statement.execute("delete from Student where rowid="+students[row][0]);
                
            } catch (SQLException ex) {
                Logger.getLogger(management.class.getName()).log(Level.SEVERE, null, ex);
            }
            updateStudentTable();
        }
    }//GEN-LAST:event_student_deleteActionPerformed

    private void course_deleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_course_deleteActionPerformed
        // TODO add your handling code here:
        int row=courseTable.getSelectedRow();
         if ( row!= -1&&row<courseCount) {
            try {
                // remove selected row from the model
                statement.execute("delete from Registration where CourseId="+students[row][0]);
                statement.execute("delete from Course where rowid="+courses[row][0]);
                
            } catch (SQLException ex) {
                Logger.getLogger(management.class.getName()).log(Level.SEVERE, null, ex);
            }
            updateCourseTable();
        }        
    }//GEN-LAST:event_course_deleteActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(management.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(management.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(management.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(management.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new management().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTable courseTable;
    private javax.swing.JTextField course_code;
    private javax.swing.JButton course_delete;
    private javax.swing.JTextField course_name;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JTable regTable;
    private javax.swing.JComboBox<String> reg_course;
    private javax.swing.JButton reg_delete;
    private javax.swing.JComboBox<String> reg_semester;
    private javax.swing.JComboBox<String> reg_student;
    private javax.swing.JTable studentTable;
    private javax.swing.JTextField student_age;
    private javax.swing.JButton student_delete;
    private javax.swing.JComboBox<String> student_gender;
    private javax.swing.JTextField student_id;
    private javax.swing.JTextField student_name;
    private javax.swing.JTextField student_password;
    // End of variables declaration//GEN-END:variables
}
